// src/apollo/client.js
import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client';

const client = new ApolloClient({
  link: createHttpLink({
    uri: 'http://localhost:3000/api/graphql', // replace with your GraphQL endpoint
  }),
  cache: new InMemoryCache(),
});

export default client; // Ensure it's exported as default
