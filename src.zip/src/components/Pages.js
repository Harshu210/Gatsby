import React from 'react'
import { gql, useQuery } from '@apollo/client'

// GraphQL Query
const GET_PAGES = gql`
  query {
    Pages {
      docs {
        id
        title
        slug
        layout {
          __typename
          ... on ContentBlock {
            columns {
              size
              richText
            }
          }
          ... on MediaBlock {
            media {
              filename
              url
              alt
            }
            caption
          }
        }
      }
    }
  }
`

// Rich text parser
const renderRichText = (json) => {
  if (!json?.root?.children) return null

  return json.root.children.map((node, i) => {
    if (node.type === 'paragraph') {
      return (
        <p key={i}>
          {node.children?.map((child, j) =>
            child.text ? <span key={j}>{child.text}</span> : null
          )}
        </p>
      )
    }

    if (node.type === 'heading') {
      const Tag = node.tag || 'h2'
      return (
        <Tag key={i}>
          {node.children?.map((child, j) =>
            child.text ? <span key={j}>{child.text}</span> : null
          )}
        </Tag>
      )
    }

    return null
  })
}

// Component
export default function Pages() {
  const { loading, error, data } = useQuery(GET_PAGES)

  if (loading) return <p>Loading...</p>
  if (error) return <p>Error: {error.message}</p>

  return (
    <div>
      <h1>Pages from Payload CMS</h1>
      <ul>
        {data.Pages.docs.map((page) => (
          <li key={page.id}>
            <h2>{page.title}</h2>
            <p><em>{page.slug}</em></p>

            {page.layout?.map((block, i) => {
              switch (block.__typename) {
                case 'ContentBlock':
                  return block.columns?.map((col, j) => (
                    <div key={`content-${i}-${j}`} style={{ marginBottom: '1rem' }}>
                      {renderRichText(col.richText)}
                    </div>
                  ))

                case 'MediaBlock':
                  if (!block.media?.filename) return null
                  return (
                    <div key={`media-${i}`} style={{ marginBottom: '1rem' }}>
                      <img
                        src={`http://localhost:3000/media/${block.media.filename}`}
                        alt={block.media.alt || 'Media'}
                        style={{ maxWidth: '400px', display: 'block' }}
                      />
                      {block.caption && <p>{block.caption}</p>}
                    </div>
                  )

                default:
                  return null
              }
            })}
          </li>
        ))}
      </ul>
    </div>
  )
}
